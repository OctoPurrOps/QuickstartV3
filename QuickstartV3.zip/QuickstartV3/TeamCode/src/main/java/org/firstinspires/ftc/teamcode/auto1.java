package org.firstinspires.ftc.teamcode;

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

@Autonomous(name = "BLUE-TEST", group = "Autonomous")
public class auto1 extends OpMode {

    // Pedro follower + timers
    private Follower follower;
    private ElapsedTime pathTimer, opModeTimer;

    // Shooter
    private DcMotorEx shooter;
    private static final double SHOOTER_VELOCITY = -1600.0;

    // Intakes
    private DcMotorEx intake;
    private DcMotorEx intake2;
    private static final double INTAKE_POWER = -1.0;

    // Turret / aim motor
    private DcMotor aimMotor;

    // Turret aiming constants
    private static final double GOAL_X = 0.0;
    private static final double GOAL_Y = 144.0;
    private static final double HEADING_OFFSET = Math.toRadians(0);
    private static final double TICKS_PER_REV = 1627;
    private static final double AIM_TICKS_PER_RAD = TICKS_PER_REV / (2.0 * Math.PI);
    private static final int AIM_MIN_TICKS = -2000;
    private static final int AIM_MAX_TICKS = 2000;
    private static final double AIM_POWER = 1;

    // Paths holder
    public static class Paths {
        public PathChain Path1, Path2, Path3, Path4, Path5, Path6, Path7, Path8, Path9, Path10, Path11;

        public Paths(Follower follower) {

            Path1 = follower.pathBuilder().addPath(
                            new BezierLine(
                                    new Pose(27.000, 130.000),

                                    new Pose(58.000, 100.000)
                            )
                    ).setConstantHeadingInterpolation(Math.toRadians(144))

                    .build();

            Path2 = follower.pathBuilder().addPath(
                            new BezierLine(
                                    new Pose(58.000, 100.000),

                                    new Pose(30.000, 100.000)
                            )
                    ).setTangentHeadingInterpolation()

                    .build();

            Path3 = follower.pathBuilder().addPath(
                            new BezierLine(
                                    new Pose(30.000, 100.000),

                                    new Pose(58.000, 100.000)
                            )
                    ).setTangentHeadingInterpolation()

                    .build();

        }
    }

    private Paths paths;

    // State machine
    public enum PathState {
        PATH_1,
        WAIT_AFTER_PATH_1,  // 5s wait; intakes run here then stop
        PATH_2,
        PATH_3,
        WAIT_AFTER_PATH_3,  // 5s wait; intakes run here then stop
        PATH_4,
        PATH_5,
        PATH_6,
        WAIT_AFTER_PATH_6,  // 5s; both intakes run then stop
        PATH_7,
        PATH_8,
        END_AT_PATH_8,      // robot stops & both intakes run
        PATH_9,
        PATH_10,
        PATH_11,
        DONE
    }

    private PathState pathState = PathState.PATH_1;

    private void setPathState(PathState newState) {
        pathState = newState;
        if (pathTimer != null) pathTimer.reset();
    }

    // Shooter helper: ON whole time for PATH_1, PATH_3, PATH_6, PATH_9
    private void updateShooterForState() {
        boolean enable =
                (pathState == PathState.PATH_1) ||
                        (pathState == PathState.PATH_3) ||
                        (pathState == PathState.PATH_6) ||
                        (pathState == PathState.PATH_9);

        if (enable) {
            shooter.setVelocity(SHOOTER_VELOCITY);
        } else {
            shooter.setVelocity(0);
        }
    }

    // -------------------- STATE MACHINE --------------------
    private void updateStateMachine() {
        switch (pathState) {

            // ---------------- PATH 1 ----------------
            case PATH_1:
                updateShooterForState(); // shooter ON whole Path1
                // Path1 was started in start(), just wait for it to finish
                if (!follower.isBusy()) {
                    setPathState(PathState.WAIT_AFTER_PATH_1);
                }
                break;

            case WAIT_AFTER_PATH_1:
                updateShooterForState(); // shooter OFF in wait
                // As soon as we enter: run both intakes
                if (pathTimer.seconds() < 0.05) {
                    intake.setPower(INTAKE_POWER);
                    intake2.setPower(INTAKE_POWER);
                }
                // Keep both intakes on for full 5s, then stop them and go to Path2
                if (pathTimer.seconds() >= 5.0) {
                    intake.setPower(0);
                    intake2.setPower(0);
                    follower.followPath(paths.Path2, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_2);
                }
                break;

            // ---------------- PATH 2 ----------------
            case PATH_2:
                updateShooterForState(); // shooter OFF on path2
                // In beginning: intake2 runs briefly, intake runs whole path
                if (pathTimer.seconds() < 0.1) {
                    intake2.setPower(INTAKE_POWER);  // short pulse
                    intake.setPower(INTAKE_POWER);   // start intake for whole path
                } else {
                    // Stop intake2 after brief time
                    intake2.setPower(0);
                    // Keep intake running during whole path2
                    intake.setPower(INTAKE_POWER);
                }

                if (!follower.isBusy()) {
                    // End of path2: stop intake (so it doesn't run constantly into path3)
                    intake.setPower(0);
                    follower.followPath(paths.Path3, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_3);
                }
                break;

            // ---------------- PATH 3 ----------------
            case PATH_3:
                updateShooterForState(); // shooter ON whole Path3
                if (!follower.isBusy()) {
                    // When finished path3, go to waiting state with 5s stop then both intakes
                    setPathState(PathState.WAIT_AFTER_PATH_3);
                }
                break;

            case WAIT_AFTER_PATH_3:
                updateShooterForState(); // shooter OFF
                // First 5 seconds: robot stopped
                if (pathTimer.seconds() < 5.0) {
                    // intakes off during pure stop
                    intake.setPower(0);
                    intake2.setPower(0);
                } else if (pathTimer.seconds() < 10.0) {
                    // After 5s, run both intakes
                    intake.setPower(INTAKE_POWER);
                    intake2.setPower(INTAKE_POWER);
                } else {
                    // Stop intakes and continue to Path4
                    intake.setPower(0);
                    intake2.setPower(0);
                    follower.followPath(paths.Path4, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_4);
                }
                break;

            // ---------------- PATH 4 ----------------
            case PATH_4:
                updateShooterForState(); // shooter OFF on path4
                // No special intake behavior here
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path5, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_5);
                }
                break;

            // ---------------- PATH 5 ----------------
            case PATH_5:
                updateShooterForState(); // shooter OFF on path5
                // At beginning: intake2 runs a little bit, intake whole path
                if (pathTimer.seconds() < 0.1) {
                    intake2.setPower(INTAKE_POWER);      // small pulse
                    intake.setPower(INTAKE_POWER);       // start main intake
                } else {
                    intake2.setPower(0);                 // stop intake2
                    intake.setPower(INTAKE_POWER);       // keep main intake running whole path
                }

                if (!follower.isBusy()) {
                    // End of path5: stop intake before path6 if you only want it on path5
                    intake.setPower(0);
                    follower.followPath(paths.Path6, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_6);
                }
                break;

            // ---------------- PATH 6 ----------------
            case PATH_6:
                updateShooterForState(); // shooter ON whole Path6
                // No special intake during path6 (off unless you want otherwise)
                intake.setPower(0);
                intake2.setPower(0);

                if (!follower.isBusy()) {
                    // At end of path6: both intakes will work (in WAIT_AFTER_PATH_6)
                    setPathState(PathState.WAIT_AFTER_PATH_6);
                }
                break;

            case WAIT_AFTER_PATH_6:
                updateShooterForState(); // shooter OFF
                // Both intakes run while waiting
                if (pathTimer.seconds() < 5.0) {
                    intake.setPower(INTAKE_POWER);
                    intake2.setPower(INTAKE_POWER);
                } else {
                    // Stop intakes and move to path7
                    intake.setPower(0);
                    intake2.setPower(0);
                    follower.followPath(paths.Path7, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_7);
                }
                break;

            // ---------------- PATH 7 ----------------
            case PATH_7:
                updateShooterForState(); // shooter OFF on path7
                // No intake actions here
                if (!follower.isBusy()) {
                    follower.followPath(paths.Path8, true);
                    follower.setMaxPower(1.0);
                    setPathState(PathState.PATH_8);
                }
                break;

            // ---------------- PATH 8 ----------------
            case PATH_8:
                updateShooterForState(); // shooter OFF on path8
                // At beginning of path8: intake2 a bit, intake full path
                if (pathTimer.seconds() < 0.1) {
                    intake2.setPower(INTAKE_POWER);  // brief
                    intake.setPower(INTAKE_POWER);   // full path
                } else {
                    intake2.setPower(0);
                    intake.setPower(INTAKE_POWER);
                }

                if (!follower.isBusy()) {
                    // End of path8: robot stops and both intakes work
                    setPathState(PathState.END_AT_PATH_8);
                    pathTimer.reset();
                }
                break;

            case END_AT_PATH_8:
                updateShooterForState(); // shooter OFF here
                // Robot stopped, both intakes run (no time limit; stop when auto ends)
                intake.setPower(INTAKE_POWER);
                intake2.setPower(INTAKE_POWER);
                break;

            // ---------------- PATH 9 ----------------
            case PATH_9:
                updateShooterForState(); // shooter ON whole Path9
                if (!follower.isBusy()) {
                    if (paths.Path10 != null) {
                        follower.followPath(paths.Path10, true);
                        follower.setMaxPower(1.0);
                        setPathState(PathState.PATH_10);
                    } else {
                        setPathState(PathState.DONE);
                    }
                }
                break;

            case PATH_10:
                updateShooterForState();
                if (!follower.isBusy()) {
                    if (paths.Path11 != null) {
                        follower.followPath(paths.Path11, true);
                        follower.setMaxPower(1.0);
                        setPathState(PathState.PATH_11);
                    } else {
                        setPathState(PathState.DONE);
                    }
                }
                break;

            case PATH_11:
                updateShooterForState();
                if (!follower.isBusy()) {
                    setPathState(PathState.DONE);
                }
                break;

            case DONE:
                updateShooterForState();
                // Hold pose, everything else left as-is
                break;
        }
    }

    // -------------------- TURRET AIM LOGIC --------------------
    private void updateTurretAim() {
        if (aimMotor == null) return;

        Pose p = follower.getPose();

        double dx = GOAL_X - p.getX();
        double dy = GOAL_Y - p.getY();

        double goalFieldHeading = Math.atan2(dy, dx) + HEADING_OFFSET;
        double desiredTurretRad = AngleUnit.normalizeRadians(goalFieldHeading - p.getHeading());

        int targetTicks = (int) Math.round(desiredTurretRad * AIM_TICKS_PER_RAD);
        targetTicks = clampInt(targetTicks, AIM_MIN_TICKS, AIM_MAX_TICKS);

        aimMotor.setTargetPosition(targetTicks);
    }

    private static int clampInt(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // -------------------- LIFECYCLE --------------------
    @Override
    public void init() {
        try {
            pathTimer = new ElapsedTime();
            opModeTimer = new ElapsedTime();

            follower = Constants.createFollower(hardwareMap);
            follower.setPose(new Pose(27, 130, Math.toRadians(144)));

            // Shooter init
            shooter = hardwareMap.get(DcMotorEx.class, "shooter1");
            shooter.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            shooter.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            shooter.setDirection(DcMotorSimple.Direction.REVERSE);

            // Intakes init
            intake  = hardwareMap.get(DcMotorEx.class, "intake");
            intake2 = hardwareMap.get(DcMotorEx.class, "intake2");
            intake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            intake2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            intake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            intake2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

            intake.setDirection(DcMotorSimple.Direction.FORWARD);
            intake2.setDirection(DcMotorSimple.Direction.REVERSE);

            // Aim motor
            aimMotor = hardwareMap.get(DcMotor.class, "aimMotor");
            aimMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            aimMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            aimMotor.setTargetPosition(0);
            aimMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            aimMotor.setDirection(DcMotorSimple.Direction.REVERSE);
            aimMotor.setPower(AIM_POWER);

            // Paths
            paths = new Paths(follower);

            telemetry.addLine("✅ Blue Auto READY");
            telemetry.update();

        } catch (Exception e) {
            telemetry.addLine("❌ Init Error: " + e.getMessage());
            telemetry.update();
        }
    }

    @Override
    public void start() {
        opModeTimer.reset();
        pathTimer.reset();

        // Start in PATH_1; shooter logic handled in state machine
        shooter.setVelocity(0);

        intake.setPower(0);
        intake2.setPower(0);

        // Start first path once, here
        follower.followPath(paths.Path1, true);
        follower.setMaxPower(1.0);
        setPathState(PathState.PATH_1);
    }

    @Override
    public void loop() {
        try {
            follower.update();

            updateStateMachine();
            updateTurretAim();

            telemetry.addData("State", pathState);
            telemetry.addData("Pose", follower.getPose());
            telemetry.addData("OpMode Time", opModeTimer.seconds());
            telemetry.addData("State Time", pathTimer.seconds());
            telemetry.addData("Shooter Vel Cmd", SHOOTER_VELOCITY);
            telemetry.addData("Shooter Vel Actual", shooter.getVelocity());
            telemetry.addData("Intake Power", intake.getPower());
            telemetry.addData("Intake2 Power", intake2.getPower());
            telemetry.addData("Aim Target", aimMotor.getTargetPosition());
            telemetry.addData("Aim Current", aimMotor.getCurrentPosition());
            telemetry.update();

        } catch (Exception e) {
            telemetry.addLine("Loop Error: " + e.getMessage());
            telemetry.update();
        }
    }

    @Override
    public void stop() {
        if (shooter != null) {
            shooter.setVelocity(0);
            shooter.setPower(0);
        }
        if (intake != null) intake.setPower(0);
        if (intake2 != null) intake2.setPower(0);
        if (aimMotor != null) aimMotor.setPower(0);
    }
}
